import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;

public class customerbooking {

	static Registeror registers = new Registeror();
    public static void main (String[] args)
    		throws IOException {
    	System.out.println("Hello , Welcome to Super Cab \n please book taxi from here ...");
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print(" Enter Name => ");
            String firstName = scanner.nextLine();
            registers.setName(firstName);

            System.out.print(" Enter longitude => ");
            String longitude = scanner.nextLine();
            registers.setlongitude(longitude);
            
            System.out.print(" Enter latitude => ");
            String latitude = scanner.nextLine();
            registers.setlatitude(latitude);
                       

            System.out.print(" Enter emailId => ");
            String emailId = scanner.nextLine();
            registers.setEmailId(emailId);

            System.out.print(" Enter phoneNo => ");
            long phoneNo = scanner.nextLong();
            registers.setPhoneNo(phoneNo);

            Path fileName = Path.of(
                    "A:\\\\git\\\\java ass\\\\databases files\\\\passengerlocation.txt");
            Files.writeString(fileName, longitude + latitude);
            
            System.out.println(registers.toString());
            System.out.println("THANKS FOR BOOKING>>>>");
        }
    }
}

class Registeror {
    private String Name;
    private String latitude;
    private String longitude;
    private String emailId;
    private long phoneNo;
    
    
    
    public String getName() {
        return Name;
    }
    public void setName(String Name) {
        this.Name = Name;
    }
    
    
    public String getlatitude() {
        return latitude;
    }
    public void setlatitude(String latitude) {
        this.latitude = latitude;
    }
    
    
    public String getlongitude() {
        return longitude;
    }
    public void setlongitude(String longitude) {
        this.longitude= longitude;
    }
    
    
    public String getEmailId() {
        return emailId;
    }
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }
    
    
    public long getPhoneNo() {
        return phoneNo;
    }
    public void setPhoneNo(long phoneNo) {
        this.phoneNo = phoneNo;
    }
    
}