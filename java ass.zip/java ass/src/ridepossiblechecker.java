import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileReader;
public class ridepossiblechecker {
	public static void main(String[] args) throws IOException
    {   
        BufferedReader reader1 = new BufferedReader(new FileReader("A:\\git\\java ass\\databases files\\driverlocation.txt"));
         
        BufferedReader reader2 = new BufferedReader(new FileReader("A:\\git\\java ass\\databases files\\passengerlocation.txt"));
         
        String line1 = reader1.readLine();
         
        String line2 = reader2.readLine();
         
        boolean areEqual = true;
         
        int lineNum = 1;
         
        while (line1 != null || line2 != null)
        {
            if(line1 == null || line2 == null)
            {
                areEqual = false;
                 
                break;
            }
            else if(! line1.equalsIgnoreCase(line2))
            {
                areEqual = false;
                 
                break;
            }
             
            line1 = reader1.readLine();
             
            line2 = reader2.readLine();
             
            lineNum++;
        }
         
        if(areEqual)
        {
            System.out.println("driver and passenger are at same location so ride is possible..");
        }
        else
        {
            System.out.println("driver and passenger are at diffrent location so ride is not possible.. "+lineNum);
             
            System.out.println("driver location: "+line1+" and passenger location :"+line2);
            		}
         
        reader1.close();
         
        reader2.close();
    }
}
