import java.io.IOException;
import java.util.Scanner;

import java.nio.file.Files;
import java.nio.file.Path;
public class driverlocationinfo {
	static Registering registers = new Registering();
    public static void main (String[] args)
    		throws IOException {
    	System.out.println("Hello SUPER CABS driver  \n please add your taxi location here ...");
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print(" Enter Name => ");
            String firstName = scanner.nextLine();
            registers.setName(firstName);

            System.out.print(" Enter longitude => ");
            String longitude = scanner.nextLine();
            registers.setlongitude(longitude);
            
            System.out.print(" Enter latitude => ");
            String latitude = scanner.nextLine();
            registers.setlatitude(latitude);
            
            Path fileName = Path.of(
                    "C:\\Users\\abhishek\\Desktop\\driverlocation.txt");
            Files.writeString(fileName, longitude + latitude);
            
            System.out.println("THANKS FOR UPDATING>>>>");
        }
    }
}

class Registering {
    private String Name;
    private String latitude;
    private String longitude;
  
    
    
    public String getName() {
        return Name;
    }
    public void setName(String Name) {
        this.Name = Name;
    }
    
    
    public String getlatitude() {
        return latitude;
    }
    public void setlatitude(String latitude) {
        this.latitude = latitude;
    }
    
    
    public String getlongitude() {
        return longitude;
    }
    public void setlongitude(String longitude) {
        this.longitude= longitude;
    }
    
    
}